# Slice Launcher rebrand notes

- App label and package: Slice Launcher / `com.slice.launcher`.
- App module and Gradle task namespace: `app_slice`.
- Accent palette: red on dark backgrounds.
- UI font: bundled `minecraft_ten.ttf` (already present in the supplied source).
- Developer attribution: Slice.
- The original LGPL license, source headers, and third-party license notices are retained.
- Some upstream repository URLs and legacy package IDs are intentionally retained for external dependency downloads and data migration compatibility; they are not the app's public branding.
- The in-app Discord destination is a generic placeholder (`https://discord.com/app`) and should be changed to your own invite before publishing.
