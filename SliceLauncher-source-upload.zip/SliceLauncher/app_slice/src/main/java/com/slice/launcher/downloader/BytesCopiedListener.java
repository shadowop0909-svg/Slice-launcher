package com.slice.launcher.downloader;

public interface BytesCopiedListener {
    void onBytesCopied(int nbytes);
}
