package com.slice.launcher.fragments;

import com.slice.launcher.modding.fabric.FabriclikeUtils;

public class FabricInstallFragment extends FabriclikeInstallFragment {

    public static final String TAG = "FabricInstallFragment";

    public FabricInstallFragment() {
        super(FabriclikeUtils.FABRIC_UTILS, TAG);
    }
}
