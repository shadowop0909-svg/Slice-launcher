package com.slice.launcher.utils.jre.classfile;

public class ClassFormatException extends Exception {
    public ClassFormatException(String s) {
        super(s);
    }
}
