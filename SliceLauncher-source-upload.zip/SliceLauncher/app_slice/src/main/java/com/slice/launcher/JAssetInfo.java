package com.slice.launcher;

import androidx.annotation.Keep;

@Keep
public class JAssetInfo
{
	public String hash;
    public int size;
}
