package com.slice.launcher.instances.profcompat;

public class ProfileBody {
    public String name;
    public String lastVersionId;
}
