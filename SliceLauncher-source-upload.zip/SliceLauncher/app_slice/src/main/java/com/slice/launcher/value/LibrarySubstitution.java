package com.slice.launcher.value;

public class LibrarySubstitution extends DependentLibrary {
    public boolean skip;
}
