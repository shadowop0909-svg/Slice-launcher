package com.slice.launcher.instances;

public interface InstanceSetter {
    void setInstanceProperties(Instance instance);
}
