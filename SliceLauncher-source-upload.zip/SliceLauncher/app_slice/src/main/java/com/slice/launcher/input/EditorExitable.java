package com.slice.launcher.input;

public interface EditorExitable {
    void exitEditor();
}
