package com.slice.launcher.input;

public interface ControlButtonMenuListener {
    void onClickedMenu();
}
