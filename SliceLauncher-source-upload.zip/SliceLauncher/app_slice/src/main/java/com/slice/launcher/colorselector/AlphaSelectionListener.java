package com.slice.launcher.colorselector;

public interface AlphaSelectionListener {
    void onAlphaSelected(int alpha);
}
