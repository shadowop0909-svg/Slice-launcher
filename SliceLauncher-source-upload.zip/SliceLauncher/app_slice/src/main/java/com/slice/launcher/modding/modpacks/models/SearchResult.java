package com.slice.launcher.modding.modpacks.models;

public class SearchResult {
    public int totalResultCount;
    public ModItem[] results;
}
