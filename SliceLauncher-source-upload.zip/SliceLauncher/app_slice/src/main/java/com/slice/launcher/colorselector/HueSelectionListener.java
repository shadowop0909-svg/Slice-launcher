package com.slice.launcher.colorselector;

public interface HueSelectionListener {
   void onHueSelected(float hue);
}
