package com.slice.launcher.authenticator;

import androidx.annotation.NonNull;

import com.slice.launcher.authenticator.listener.LoginListener;
import com.slice.launcher.authenticator.accounts.Account;

public interface BackgroundLogin {
    void createAccount(@NonNull LoginListener loginListener, String code);
    void refreshAccount(@NonNull LoginListener loginListener, Account account);
    interface Creator {
        BackgroundLogin create();
    }
}
