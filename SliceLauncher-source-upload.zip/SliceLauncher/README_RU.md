<h1 align="center">Slice Launcher</h1>

<p align="center"><b>Разработчик: Slice</b></p>

Slice Launcher — модифицированный Android-лаунчер для Minecraft: Java Edition на основе предоставленного исходного кода Justicia. Сохранены исходные лицензии, уведомления об авторских правах и лицензии сторонних компонентов.

## Сборка
Требуются JDK 17, Android SDK/NDK, а также необходимые Git submodules и внешние native-библиотеки.

```bash
./gradlew :app_slice:assembleFullDebug
```

Сборка без встроенного runtime:

```bash
./gradlew :app_slice:assembleNoruntimeDebug
```

## Брендинг
- Название: Slice Launcher
- Разработчик: Slice
- Android application ID: `com.slice.launcher`

Перед публикацией замените общий Discord URL в `app_slice/src/main/res/values/strings.xml` на собственную ссылку. Сохраняйте `LICENSE`, заголовки исходных файлов и лицензии сторонних компонентов при распространении изменённых сборок.
