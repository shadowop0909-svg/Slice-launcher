<h1 align="center">Slice Launcher</h1>

<p align="center"><b>Developer: Slice</b></p>

<p align="center"><img src="./app_slice/src/main/assets/slice.png" width="180" alt="Slice Launcher logo"></p>

Slice Launcher is a customized open-source Android launcher for Minecraft: Java Edition. It is based on the provided Justicia launcher source and retains its upstream code and third-party components under their original licenses.

## Features
- Launch many Minecraft: Java Edition versions on Android.
- Support for Forge, Fabric, and other mod-loader installers where supported by the upstream code.
- Custom controls, Java runtime management, rendering choices, and modpack support.

## Build
Use JDK 17 and Android SDK/NDK versions declared by the project. Ensure required Git submodules and external native libraries are available before building.

```bash
./gradlew :app_slice:assembleFullDebug
```

For a no-runtime debug build:

```bash
./gradlew :app_slice:assembleNoruntimeDebug
```

## Developer branding
- App name: Slice Launcher
- Developer attribution: Slice
- Android application ID: `com.slice.launcher`

Replace the generic Discord URL in `app_slice/src/main/res/values/strings.xml` with your own community invite before publishing.

## Licenses and upstream attribution
This is a rebrand of an existing launcher codebase, not an entirely new implementation. Preserve the original copyright notices and license files when distributing modified builds. The project includes LGPL-licensed launcher code and separately licensed third-party components; see `LICENSE`, the source-file headers, and the `app_slice/src/main/assets/licenses/` directory. Upstream dependency URLs remain unchanged where required to keep downloading compatible native libraries and game components.
